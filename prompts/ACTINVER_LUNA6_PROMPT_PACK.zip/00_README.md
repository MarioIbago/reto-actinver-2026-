# Actinver Prompt Pack — Luna 6 / Astra

Este paquete convierte el proyecto `MarioIbago/reto-actinver-2026-` en un flujo de trabajo autónomo, verificable y modular.

## Objetivo

Que Luna 6 / Astra:

- inspeccione el repo;
- continúe desde el estado real;
- decida qué problema atacar;
- investigue;
- use Perplexity Deep Research cuando corresponda;
- implemente;
- pruebe;
- depure;
- haga commits/PRs;
- valide resultados;
- mantenga Excel + CLI;
- y solo escale a Isauro cuando exista una decisión humana real.

## Regla central

No usar un solo prompt monolítico para todo.

Usar:

1. `01_MASTER_ORCHESTRATOR.md`
2. cargar módulos según el tipo de trabajo.

## Módulos

- `01_MASTER_ORCHESTRATOR.md` — cerebro principal.
- `02_LOOP_ENGINEERING.md` — bugs, implementación, CI, commits, PRs.
- `03_RESEARCH_PERPLEXITY.md` — Perplexity Deep Research, FOMO-first y quant-first.
- `04_SCIENTIFIC_VALIDATION.md` — papers, replicación, OOS, leakage, multiple testing.
- `05_DAILY_MARKET_LOOP.md` — morning / intraday / evening.
- `06_TOURNAMENT_BRAIN.md` — rank, gap, days left, distributions.
- `07_OPERATOR_COCKPIT.md` — CLI + Excel + salida para Isauro.
- `08_HUMAN_GATES.md` — cuándo preguntar y cuándo NO preguntar.
- `09_AGENT_ROUTER.md` — cómo dividir trabajo entre subagentes.
- `10_BOOTSTRAP_PROMPT.md` — prompt corto para iniciar una sesión nueva.

## Cómo usar

En una sesión nueva:

1. carga `10_BOOTSTRAP_PROMPT.md`;
2. dale acceso al repo;
3. asegúrate de que pueda leer este pack;
4. abre Perplexity manualmente si quieres habilitar investigación web delegada;
5. deja que el Orchestrator determine el siguiente gate.

## Límite de autonomía

La automatización llega hasta:

`research → code → validation → decision → trade sheet`

No llega a:

`automatic Actinver order execution`.

La ejecución final en Actinver permanece manual.
